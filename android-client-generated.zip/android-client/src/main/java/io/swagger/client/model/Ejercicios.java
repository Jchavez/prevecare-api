package io.swagger.client.model;


import io.swagger.annotations.*;
import com.google.gson.annotations.SerializedName;


@ApiModel(description = "")
public class Ejercicios  {
  
  @SerializedName("id")
  private Long id = null;
  @SerializedName("asociado_id")
  private Long asociadoId = null;
  @SerializedName("fecha")
  private String fecha = null;
  @SerializedName("cantidad")
  private Long cantidad = null;
  @SerializedName("tiempo")
  private Long tiempo = null;
  @SerializedName("distancia")
  private Long distancia = null;
  public enum TipoEnum {
     W,  R, 
  };
  @SerializedName("tipo")
  private TipoEnum tipo = null;

  
  /**
   **/
  @ApiModelProperty(value = "")
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }

  
  /**
   **/
  @ApiModelProperty(required = true, value = "")
  public Long getAsociadoId() {
    return asociadoId;
  }
  public void setAsociadoId(Long asociadoId) {
    this.asociadoId = asociadoId;
  }

  
  /**
   **/
  @ApiModelProperty(required = true, value = "")
  public String getFecha() {
    return fecha;
  }
  public void setFecha(String fecha) {
    this.fecha = fecha;
  }

  
  /**
   **/
  @ApiModelProperty(required = true, value = "")
  public Long getCantidad() {
    return cantidad;
  }
  public void setCantidad(Long cantidad) {
    this.cantidad = cantidad;
  }

  
  /**
   **/
  @ApiModelProperty(required = true, value = "")
  public Long getTiempo() {
    return tiempo;
  }
  public void setTiempo(Long tiempo) {
    this.tiempo = tiempo;
  }

  
  /**
   **/
  @ApiModelProperty(required = true, value = "")
  public Long getDistancia() {
    return distancia;
  }
  public void setDistancia(Long distancia) {
    this.distancia = distancia;
  }

  
  /**
   * tipo
   **/
  @ApiModelProperty(value = "tipo")
  public TipoEnum getTipo() {
    return tipo;
  }
  public void setTipo(TipoEnum tipo) {
    this.tipo = tipo;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ejercicios {\n");
    
    sb.append("  id: ").append(id).append("\n");
    sb.append("  asociadoId: ").append(asociadoId).append("\n");
    sb.append("  fecha: ").append(fecha).append("\n");
    sb.append("  cantidad: ").append(cantidad).append("\n");
    sb.append("  tiempo: ").append(tiempo).append("\n");
    sb.append("  distancia: ").append(distancia).append("\n");
    sb.append("  tipo: ").append(tipo).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
